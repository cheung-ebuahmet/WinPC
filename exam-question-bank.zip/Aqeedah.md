# Aqeedah

> 存放 Aqeedah（信仰学/教义）的题目与答案。
> 追加格式：`## Q###` 标题 + `**题目 (Question):**` + `**答案 (Answer):**`，题与题之间用 `---` 分隔，编号由 Claude 自动递增。

---

## Q001

**题目 (Question):**

The ruling on travelling by car is:

**答案 (Answer):**

that it is not an innovation (bidah).

---

## Q002

**题目 (Question):**

The evidence quoted by those who say that there is such a thing as good innovation (bidah hasanah) includes:

**答案 (Answer):**

the words of Umar (RA) regarding Taraweeh: "What a good innovation (bidah) this is."

> ⚠️ 易混点：选项中的圣训 "Whoever introduces into this matter of ours anything that is not part of it, it will be rejected" 是**反对方**（主张不存在 bidah hasanah）的经典依据，别误当作支持 bidah hasanah 的证据。
